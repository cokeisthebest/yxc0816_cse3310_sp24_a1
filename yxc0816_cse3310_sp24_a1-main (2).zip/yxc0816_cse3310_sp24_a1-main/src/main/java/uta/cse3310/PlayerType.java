package uta.cse3310;

// A player can be an X or an O

public enum PlayerType {
    NOPLAYER, XPLAYER, OPLAYER
}
